﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppRegistroLutadores.Contexto
{
    public class Contexto
    {
       public List<string> listaLutadores;
       public List<string> listaLutas;
       public List<string> listaVencedores;
    }
}
