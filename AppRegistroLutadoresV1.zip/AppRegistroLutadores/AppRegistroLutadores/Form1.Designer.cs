﻿namespace AppRegistroLutadores
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCadastrarLutador = new System.Windows.Forms.TextBox();
            this.txtCadastrarLuta = new System.Windows.Forms.TextBox();
            this.txtCadastrarVencedor = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtCadastrarLutador
            // 
            this.txtCadastrarLutador.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCadastrarLutador.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCadastrarLutador.Location = new System.Drawing.Point(40, 33);
            this.txtCadastrarLutador.Name = "txtCadastrarLutador";
            this.txtCadastrarLutador.Size = new System.Drawing.Size(740, 38);
            this.txtCadastrarLutador.TabIndex = 0;
            this.txtCadastrarLutador.Text = "Cadastrar Lutador";
            this.txtCadastrarLutador.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCadastrarLuta
            // 
            this.txtCadastrarLuta.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCadastrarLuta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCadastrarLuta.Location = new System.Drawing.Point(40, 117);
            this.txtCadastrarLuta.Name = "txtCadastrarLuta";
            this.txtCadastrarLuta.Size = new System.Drawing.Size(740, 38);
            this.txtCadastrarLuta.TabIndex = 1;
            this.txtCadastrarLuta.Text = "Cadastrar Luta";
            this.txtCadastrarLuta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCadastrarVencedor
            // 
            this.txtCadastrarVencedor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCadastrarVencedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCadastrarVencedor.Location = new System.Drawing.Point(40, 198);
            this.txtCadastrarVencedor.Name = "txtCadastrarVencedor";
            this.txtCadastrarVencedor.Size = new System.Drawing.Size(740, 38);
            this.txtCadastrarVencedor.TabIndex = 2;
            this.txtCadastrarVencedor.Text = "Cadastrar Vencedor";
            this.txtCadastrarVencedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 472);
            this.Controls.Add(this.txtCadastrarVencedor);
            this.Controls.Add(this.txtCadastrarLuta);
            this.Controls.Add(this.txtCadastrarLutador);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCadastrarLutador;
        private System.Windows.Forms.TextBox txtCadastrarLuta;
        private System.Windows.Forms.TextBox txtCadastrarVencedor;
    }
}

