﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppRegistroLutadores.Models
{
    public class Luta
    {
        public int Id { get; set; } // chave primária da luta
        public int IdLutador { get; set; } // chave estrangeira do lutador
        public DateTime DataLuta { get; set; }
        public string LocalLuta { get; set; } 
    }
}
