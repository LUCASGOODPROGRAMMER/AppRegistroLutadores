﻿using AppRegistroLutadores.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppRegistroLutadores.Contexto
{
    public static class Context
    {
        public static List<Lutador> listaLutadores = new List<Lutador>(); // onde vou salvar o cadastro de cada lutador
        public static List<Luta> listaLutas = new List<Luta>(); // onde eu vou salvar os dados das lutas a ser realizada
    }
}
