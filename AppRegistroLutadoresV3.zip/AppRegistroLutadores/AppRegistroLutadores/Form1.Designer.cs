﻿namespace AppRegistroLutadores
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCadastrarLutador = new System.Windows.Forms.Button();
            this.btCadastrarLuta = new System.Windows.Forms.Button();
            this.btCadastrarVencedor = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btCadastrarLutador
            // 
            this.btCadastrarLutador.AutoSize = true;
            this.btCadastrarLutador.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastrarLutador.Location = new System.Drawing.Point(27, 33);
            this.btCadastrarLutador.Name = "btCadastrarLutador";
            this.btCadastrarLutador.Size = new System.Drawing.Size(348, 41);
            this.btCadastrarLutador.TabIndex = 3;
            this.btCadastrarLutador.Text = "CADASTRAR LUTADOR";
            this.btCadastrarLutador.UseVisualStyleBackColor = true;
            this.btCadastrarLutador.Click += new System.EventHandler(this.btCadastrarLutador_Click);
            // 
            // btCadastrarLuta
            // 
            this.btCadastrarLuta.AutoSize = true;
            this.btCadastrarLuta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastrarLuta.Location = new System.Drawing.Point(27, 127);
            this.btCadastrarLuta.Name = "btCadastrarLuta";
            this.btCadastrarLuta.Size = new System.Drawing.Size(348, 41);
            this.btCadastrarLuta.TabIndex = 4;
            this.btCadastrarLuta.Text = "CADASTRAR LUTA";
            this.btCadastrarLuta.UseVisualStyleBackColor = true;
            // 
            // btCadastrarVencedor
            // 
            this.btCadastrarVencedor.AutoSize = true;
            this.btCadastrarVencedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCadastrarVencedor.Location = new System.Drawing.Point(11, 419);
            this.btCadastrarVencedor.Name = "btCadastrarVencedor";
            this.btCadastrarVencedor.Size = new System.Drawing.Size(373, 41);
            this.btCadastrarVencedor.TabIndex = 5;
            this.btCadastrarVencedor.Text = "CADASTRAR VENCEDOR";
            this.btCadastrarVencedor.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.AutoSize = true;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(27, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(348, 41);
            this.button1.TabIndex = 6;
            this.button1.Text = "LISTA DE LUTADORES";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 472);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btCadastrarVencedor);
            this.Controls.Add(this.btCadastrarLuta);
            this.Controls.Add(this.btCadastrarLutador);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btCadastrarLutador;
        private System.Windows.Forms.Button btCadastrarLuta;
        private System.Windows.Forms.Button btCadastrarVencedor;
        private System.Windows.Forms.Button button1;
    }
}

