﻿using AppRegistroLutadores.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroLutadores.Contexto;

namespace AppRegistroLutadores.Formularios
{
    public partial class FormCadastrarLuta : Form
    {
        List<Lutador> lutadores = new List<Lutador>();
        public int numeroDeRegistros = 1;
        public FormCadastrarLuta()
        {
            InitializeComponent();
            lutadores = Context.listaLutadores.ToList();

            cbLutador1.DataSource = lutadores.ToList();
            cbLutador1.DisplayMember = "Nome";
            cbLutador1.SelectedIndex = -1;

            cbLutador2.DataSource = lutadores.ToList();
            cbLutador2.DisplayMember = "Nome";
            cbLutador2.SelectedIndex = -1;
        }

       

        private void cbLutador2_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selecioarLutador2 = cbLutador2.SelectedIndex;
        }

        private void cbLutador1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selecionarLutador1 = cbLutador1.SelectedIndex;
            if (selecionarLutador1 > -1 && selecionarLutador1 > numeroDeRegistros)
            {

            }
            numeroDeRegistros++;

        }
    }
}
