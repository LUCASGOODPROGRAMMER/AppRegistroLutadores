﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroLutadores.Models;
using AppRegistroLutadores.Contexto;
namespace AppRegistroLutadores.Formularios
{
    public partial class FormCadastrarLutador : Form
    {
        public Lutador lutador = new Lutador();
        public List<Lutador> lutadores;
        int IdLutador = 1;

        public FormCadastrarLutador()
        {
            InitializeComponent();
        }

        

        private void btSave_Click(object sender, EventArgs e)
        {
            Lutador lutador = new Lutador();

            lutador.Altura = Convert.ToDouble(txtAltura.Text);// dados do lutador
            lutador.categoria = txtCategoria.Text;
            lutador.Nome = txtNome.Text;
            lutador.Id = IdLutador; // posição do salvamento para eu usar na consulta

            Context.listaLutadores.Add(lutador);
            MessageBox.Show("LUTADOR CADASTRADO!", "ANFILTRIÃO", MessageBoxButtons.OK, MessageBoxIcon.Information);
            txtAltura.Clear();
            txtCategoria.Clear();
            txtNome.Clear();
            txtNome.Select();
            IdLutador++;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            txtAltura.Clear();
            txtCategoria.Clear();
            txtNome.Clear();
            txtNome.Select();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.ShowDialog();
        }
    }
}
