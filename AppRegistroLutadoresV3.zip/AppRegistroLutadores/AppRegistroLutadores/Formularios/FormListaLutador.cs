﻿using AppRegistroLutadores.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AppRegistroLutadores.Contexto;

namespace AppRegistroLutadores.Formularios
{
    public partial class FormListaLutador : Form
    {
        List<Lutador> lutadores = new List<Lutador>();
        public FormListaLutador()
        {
            InitializeComponent();
            lutadores = Context.listaLutadores.ToList();
            dtListaLutadores.DataSource = lutadores.ToList() ;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
